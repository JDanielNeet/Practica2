

import UIKit

class RecetaViewController: UIViewController {

    
    @IBOutlet var noNetworkView: UIView!
    @IBOutlet weak var recetaTableView: UITableView!
    
    var recetaManager : RecetasManager?
    var receta: Recetas?
    
    var recetasList: [Recetas] = []
    
    var isEdit : Bool = false
    var editIndex : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        recetaManager = RecetasManager()
        if ((recetaManager?.getCocktailCount() == 0) || (recetaManager?.monitor.connectionType == "Datos Moviles")){
            noNetworkView.isHidden = false
            recetaTableView?.backgroundView = noNetworkView
        }else{
            noNetworkView?.isHidden = true
        }
        
    }

}

extension RecetaViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        recetasList = (recetaManager?.getCocktailList())!
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? RecetaViewCell
        cell?.nameLabel.text = recetasList[indexPath.row].name
        cell?.ingredientsLabel.text = recetasList[indexPath.row].ingredients
        cell?.descriptionLabel.text = recetasList[indexPath.row].directions
        //cell?.cocktailImage.image = recetasList[indexPath.row].img
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if recetaManager?.getCocktailCount() == 0{
            noNetworkView.isHidden = false
            recetaTableView.backgroundView = noNetworkView
        }
        
        else{
            noNetworkView?.isHidden = true
        }
        
        return recetaManager!.getCocktailCount()
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        editIndex = indexPath.row
        //
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            recetaManager?.deleteCocktail(at: indexPath.row)
            recetaManager?.saveCocktails()
        }
        
        recetaManager?.loadCocktails()
    }
    
    
    
}
