

import UIKit

class RecetaViewController: UIViewController {

    
    @IBOutlet var noNetworkView: UIView!
    @IBOutlet weak var recetaTableView: UITableView!
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    
    var recetaManager : RecetasManager?
    var receta: Recetas?
    
    var recetasList: [Recetas] = []
    
    var detailIndex : Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        recetaManager = RecetasManager()
        if ((recetaManager?.monitor.connectionType == "Datos Moviles")){
            noNetworkView.isHidden = false
            recetaTableView?.backgroundView = noNetworkView
        }else{
            noNetworkView?.isHidden = true
        }
        
    }
    
    
    @IBAction func addReceta(_ sender: Any) {
        performSegue(withIdentifier: "addSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailSegue"{
            let destination = segue.destination as! DetailRecetaViewController
            destination.detailCocktail = recetaManager?.getCocktail(at: detailIndex)
        }
        
        if segue.identifier ==  "addSegue"{
            let destination = segue.destination as! AddRecetaViewController
            destination.newValue = (recetaManager?.getCocktailCount())!
        }
        
    }
    
    
    
}

extension RecetaViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        recetasList = (recetaManager?.getCocktailList())!
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? RecetaViewCell
        cell?.nameLabel.text = recetasList[indexPath.row].name
        
        let imageString = recetasList[indexPath.row].img
        if let imageUrl = URL(string: imageString){
            let fileManager = FileManager.default
            let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
            let imageURL = documentsDirectory.appending(path: recetasList[indexPath.row].img)
            
            //Check if file exists
            if fileManager.fileExists(atPath: imageURL.path){
                
            }
            else{
                recetaManager?.getCocktail(at: indexPath.row)
            }
        }
        return cell!
            
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if recetaManager?.getCocktailCount() == 0{
            noNetworkView.isHidden = false
            recetaTableView.backgroundView = noNetworkView
        }
        
        else{
            noNetworkView?.isHidden = true
        }
        
        return recetaManager!.getCocktailCount()
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        detailIndex = indexPath.row
        performSegue(withIdentifier: "detailSegue", sender: self)
        //
    }
    
    
    @IBAction func unwindToRecetaViewController(segue: UIStoryboardSegue){
        let source = segue.source as! AddRecetaViewController
        receta = source.newReceta
        
        recetaManager?.createCocktail(cocktail: receta!)
        recetaManager?.saveCocktails()
        
        
        recetaManager?.loadCocktails()
        //reload table view
        recetaTableView.reloadData()
    }
    
}
