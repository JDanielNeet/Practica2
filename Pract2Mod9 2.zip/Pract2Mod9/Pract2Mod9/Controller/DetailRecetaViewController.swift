
import UIKit

class DetailRecetaViewController: UIViewController {

    var detailCocktail: Recetas?
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cocktailImage: UIImageView!
    @IBOutlet weak var ingredientesText: UITextView!
    @IBOutlet weak var descripcionText: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel.text = detailCocktail?.name
        ingredientesText.text = detailCocktail?.ingredients
        descripcionText.text = detailCocktail?.directions
        
        let fileManager = FileManager.default
        let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        var data : Data?

        let imageURL = documentsDirectory.appending(path:detailCocktail?.img ?? "0.jpg")
            //Check if file exists
        if fileManager.fileExists(atPath: imageURL.path){
                do{
                    data = try Data(contentsOf: imageURL)
                    cocktailImage.image = UIImage(data: data!)
                }
                
                catch{
                    print("Error loading image")
                    print(error)
                }
            }
        else{
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
