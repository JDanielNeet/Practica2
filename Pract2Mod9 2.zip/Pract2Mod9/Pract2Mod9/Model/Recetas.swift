
import Foundation

struct Recetas : Codable{
    var directions: String
    var ingredients: String
    var name: String
    var img: String
}
